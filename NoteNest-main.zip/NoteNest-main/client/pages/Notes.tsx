import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { store } from "@/lib/store";
import { Note } from "@shared/api";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

function useNotes() {
  const [notes, setNotes] = useState<Note[]>([]);
  useEffect(() => {
    setNotes(store.get<Note[]>("notes", []));
  }, []);
  useEffect(() => {
    store.set("notes", notes);
  }, [notes]);
  return { notes, setNotes };
}

export default function NotesPage() {
  const { notes, setNotes } = useNotes();
  const [filter, setFilter] = useState("");
  const tags = useMemo(
    () => Array.from(new Set(notes.flatMap((n) => n.tags))).sort(),
    [notes],
  );

  const filtered = useMemo(() => {
    const f = filter.toLowerCase();
    let list = notes.slice();
    // pinned notes first
    list.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
    if (!f) return list;
    return list.filter(
      (n) =>
        n.title.toLowerCase().includes(f) ||
        n.content.toLowerCase().includes(f) ||
        n.tags.some((t) => t.toLowerCase().includes(f)),
    );
  }, [filter, notes]);

  return (
    <AppLayout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Folders / Tags</CardTitle>
              <CardDescription>Organize your notes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Input
                placeholder="Filter tags"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              />
              <div className="flex flex-wrap gap-2 pt-2">
                {tags.length === 0 && (
                  <span className="text-sm text-muted-foreground">
                    No tags yet
                  </span>
                )}
                {tags.map((t) => (
                  <button
                    key={t}
                    className="rounded-full border px-3 py-1 text-sm hover:bg-accent"
                    onClick={() => setFilter(t)}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>New Note</CardTitle>
              <CardDescription>Add your own or paste content</CardDescription>
            </CardHeader>
            <CardContent>
              <NewNote onAdd={(n) => setNotes([n, ...notes])} />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>My Notes</CardTitle>
              <CardDescription>Title, preview, last edited</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {filtered.length === 0 && (
                <div className="text-sm text-muted-foreground">
                  No notes yet
                </div>
              )}
              {filtered.map((n) => (
                <div key={n.id} className="rounded-md border p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{n.title}</div>
                      <div className="text-xs text-muted-foreground">
                        Edited {new Date(n.updatedAt).toLocaleString()} •{" "}
                        {n.tags.join(", ")}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" onClick={() => togglePin(n.id)}>
                        {n.pinned ? "Unpin" : "Pin"}
                      </Button>
                      <Button variant="secondary" onClick={() => summarize(n)}>
                        Summarize
                      </Button>
                      <Button onClick={() => generateQuiz(n)}>
                        Generate Quiz
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => deleteNote(n.id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                  <p className="mt-2 line-clamp-3 text-sm whitespace-pre-wrap">
                    {n.content}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Generate, summarize, share</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full" onClick={() => navigateToPractice()}>
                Review Flashcards
              </Button>
              <Button
                variant="secondary"
                className="w-full"
                onClick={() => copyAll(notes)}
              >
                Copy All Notes
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );

  async function summarize(n: Note) {
    const res = await fetch("/api/ai/summarize", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: n.content, maxBullets: 6 }),
    });
    const data = await res.json();
    if (data?.bullets) {
      toast("Summary", {
        description: data.bullets.map((b: string) => `• ${b}`).join("\n"),
      });
    }
  }

  async function generateQuiz(n: Note) {
    const res = await fetch("/api/ai/quiz", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: n.content, count: 6 }),
    });
    const data = await res.json();
    if (data?.pack) {
      store.set("quiz:latest", data.pack);
      toast("Quiz ready", {
        description: `Generated ${data.pack.questions.length} questions`,
      });
    }
  }

  function copyAll(list: Note[]) {
    const text = list.map((n) => `# ${n.title}\n${n.content}`).join("\n\n");
    navigator.clipboard.writeText(text);
    toast("Copied all notes to clipboard");
  }

  function navigateToPractice() {
    location.assign("/practice");
  }

  function togglePin(id: string) {
    setNotes((prev) => {
      const updated = prev.map((p) =>
        p.id === id
          ? { ...p, pinned: !p.pinned, updatedAt: new Date().toISOString() }
          : p,
      );
      store.set("notes", updated);
      return updated;
    });
  }

  function deleteNote(id: string) {
    if (!confirm("Delete this note?")) return;
    setNotes((prev) => {
      const updated = prev.filter((p) => p.id !== id);
      store.set("notes", updated);
      toast("Note deleted");
      return updated;
    });
  }
}

function NewNote({ onAdd }: { onAdd: (n: Note) => void }) {
  const [title, setTitle] = useState("");
  const [tags, setTags] = useState("");
  const [content, setContent] = useState("");
  const [pinned, setPinned] = useState(false);
  return (
    <form
      className="space-y-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim() || !content.trim()) return;
        const tagList = tags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean);
        const now = new Date().toISOString();
        const note: Note = {
          id: Math.random().toString(36).slice(2),
          title: title.trim(),
          content: content.trim(),
          tags: tagList,
          createdAt: now,
          updatedAt: now,
          pinned: pinned,
        };
        onAdd(note);
        setTitle("");
        setTags("");
        setContent("");
        setPinned(false);
        toast("Note added");
      }}
    >
      <Input
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <Input
        placeholder="Tags (comma separated)"
        value={tags}
        onChange={(e) => setTags(e.target.value)}
      />
      <Textarea
        rows={6}
        placeholder="Paste or type your notes here..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
      <div className="flex items-center gap-2">
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={pinned}
            onChange={(e) => setPinned(e.target.checked)}
          />
          <span className="text-sm">Pin</span>
        </label>
        <div className="flex-1" />
        <Button type="submit" className="w-36">
          Add Note
        </Button>
      </div>
    </form>
  );
}
