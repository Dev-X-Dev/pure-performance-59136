import { store } from "@/lib/store";
import { Flashcard } from "@shared/api";

function deriveFlashcards(): Flashcard[] {
  const seed = store.get<{ title?: string; content?: string } | null>("flashcards:seed", null);
  const notes = store.get<any[]>("notes", []);
  const cards: Flashcard[] = [];

  const addFrom = (text: string) => {
    text
      .split(/\n+/)
      .map((l) => l.replace(/^•\s*/, "").trim())
      .filter(Boolean)
      .forEach((line) => {
        const parts = line.split(/[:–—-]/);
        const front = parts[0].trim();
        const back = parts.slice(1).join(": ").trim() || "Explain this concept";
        cards.push({ id: Math.random().toString(36).slice(2), front, back });
      });
  };

  if (seed?.content) addFrom(seed.content);
  notes.slice(0, 3).forEach((n) => addFrom(n.content));
  return cards.slice(0, 20);
}

export function FlashcardsPreview() {
  const cards = deriveFlashcards();
  if (cards.length === 0) return <div className="text-sm text-muted-foreground">No flashcards yet.</div>;
  return (
    <div className="space-y-2">
      {cards.slice(0, 3).map((c) => (
        <div key={c.id} className="rounded-md border p-3">
          <div className="text-sm font-medium">{c.front}</div>
          <div className="text-xs text-muted-foreground">{c.back}</div>
        </div>
      ))}
    </div>
  );
}
