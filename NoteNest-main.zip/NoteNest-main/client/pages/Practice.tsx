import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { store } from "@/lib/store";
import { Flashcard, QuizPack } from "@shared/api";
import { useEffect, useMemo, useState } from "react";

export default function PracticePage() {
  return (
    <AppLayout>
      <Card>
        <CardHeader>
          <CardTitle>Quizzes & Flashcards</CardTitle>
          <CardDescription>Active recall study mode</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="flash">
            <TabsList>
              <TabsTrigger value="flash">Flashcards</TabsTrigger>
              <TabsTrigger value="quiz">Quizzes</TabsTrigger>
            </TabsList>
            <TabsContent value="flash">
              <Flashcards />
            </TabsContent>
            <TabsContent value="quiz">
              <QuizMode />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

function Flashcards() {
  const seed = store.get<{ title?: string; content?: string } | null>(
    "flashcards:seed",
    null,
  );
  const notes = store.get<any[]>("notes", []);
  const derived: Flashcard[] = useMemo(() => {
    const cards: Flashcard[] = [];
    const addFrom = (text: string) => {
      text
        .split(/\n+/)
        .map((l) => l.replace(/^•\s*/, "").trim())
        .filter(Boolean)
        .forEach((line) => {
          const parts = line.split(/[:–—-]/);
          const front = parts[0].trim();
          const back =
            parts.slice(1).join(": ").trim() || "Explain this concept";
          cards.push({ id: Math.random().toString(36).slice(2), front, back });
        });
    };
    if (seed?.content) addFrom(seed.content);
    notes.slice(0, 3).forEach((n) => addFrom(n.content));
    return cards.slice(0, 20);
  }, [seed, notes]);

  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const card = derived[idx];

  if (derived.length === 0)
    return (
      <div className="text-sm text-muted-foreground">No flashcards yet.</div>
    );

  return (
    <div className="grid gap-3">
      <div className="rounded-lg border p-8 text-center bg-gradient-to-br from-blue-600/10 to-indigo-600/10">
        <div className="text-sm text-muted-foreground pb-2">
          Card {idx + 1} of {derived.length}
        </div>
        <div className="text-2xl font-semibold min-h-[4rem] flex items-center justify-center">
          {flipped ? card.back : card.front}
        </div>
      </div>
      <div className="flex gap-2">
        <Button variant="secondary" onClick={() => setFlipped((f) => !f)}>
          {flipped ? "Show Front" : "Show Answer"}
        </Button>
        <Button
          onClick={() => {
            setFlipped(false);
            setIdx((i) => (i + 1) % derived.length);
          }}
        >
          Next
        </Button>
      </div>
    </div>
  );
}

function QuizMode() {
  const latest = store.get<QuizPack | null>("quiz:latest", null);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [lastAnswered, setLastAnswered] = useState<{
    correct: boolean;
    explanation?: string;
    showCorrect?: boolean;
  } | null>(null);
  const [fillAnswer, setFillAnswer] = useState("");

  useEffect(() => {
    setI(0);
    setScore(0);
    setLastAnswered(null);
    setFillAnswer("");
  }, [latest?.id]);

  if (!latest)
    return (
      <div className="text-sm text-muted-foreground">
        No quiz generated yet. Use My Notes → Generate Quiz.
      </div>
    );

  const q = latest.questions[i];
  const isMcq = q.type === "mcq";

  return (
    <div className="space-y-4">
      <div className="text-sm text-muted-foreground">
        Question {i + 1} of {latest.questions.length}
      </div>
      <div className="rounded-md border p-4">
        <div className="font-medium">{q.prompt}</div>
        <div className="mt-2 space-y-2">
          {isMcq ? (
            q.choices!.map((c) => (
              <Button
                key={c.id}
                variant={
                  lastAnswered ? (c.correct ? "default" : "ghost") : "secondary"
                }
                className="w-full justify-start"
                onClick={() => {
                  if (lastAnswered) return;
                  handleMcqAnswer(c.correct, q.explanation);
                }}
              >
                {c.text}
              </Button>
            ))
          ) : (
            <div className="flex gap-2">
              <input
                className="flex-1 rounded-md border px-2 py-1"
                value={fillAnswer}
                onChange={(e) => setFillAnswer(e.target.value)}
              />
              <Button
                onClick={() =>
                  handleFillAnswer(fillAnswer, q.answer || "", q.explanation)
                }
                disabled={!!lastAnswered}
              >
                Submit
              </Button>
            </div>
          )}

          {lastAnswered && (
            <div className="mt-2 text-sm">
              {lastAnswered.correct ? (
                <div className="text-green-600">
                  Correct! {lastAnswered.explanation}
                </div>
              ) : (
                <div className="text-red-600">
                  Incorrect. {lastAnswered.explanation}
                </div>
              )}
              {!lastAnswered.showCorrect && (
                <div className="pt-2 flex gap-2">
                  <Button
                    variant="ghost"
                    onClick={() =>
                      setLastAnswered((s) =>
                        s ? { ...s, showCorrect: true } : s,
                      )
                    }
                  >
                    Show correct
                  </Button>
                  <Button onClick={() => nextQuestion(true)}>Next</Button>
                </div>
              )}
              {lastAnswered.showCorrect && (
                <div className="pt-2">
                  <div className="text-sm">
                    Correct answer:{" "}
                    {isMcq ? q.choices!.find((c) => c.correct)?.text : q.answer}
                  </div>
                  <div className="pt-2">
                    <Button onClick={() => nextQuestion(true)}>Next</Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="secondary" onClick={() => nextQuestion(false)}>
          Skip
        </Button>
        <div className="text-sm">Score: {score}</div>
      </div>
    </div>
  );

  function handleMcqAnswer(correct: boolean, explanation?: string) {
    if (correct) setScore((s) => s + 1);
    setLastAnswered({ correct, explanation, showCorrect: false });
  }

  function handleFillAnswer(
    given: string,
    expected: string,
    explanation?: string,
  ) {
    const norm = (s: string) => s.trim().toLowerCase();
    const correct = norm(given) === norm(expected);
    if (correct) setScore((s) => s + 1);
    setLastAnswered({
      correct,
      explanation: explanation || (correct ? "Good job" : ""),
      showCorrect: false,
    });
  }

  function nextQuestion(_answered: boolean) {
    setFillAnswer("");
    setLastAnswered(null);
    setI((x) => {
      const nx = x + 1;
      if (nx >= latest.questions.length) return 0;
      return nx;
    });
  }
}
