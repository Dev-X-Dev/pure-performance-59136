import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { store } from "@/lib/store";
import { SolveResponse } from "@shared/api";
import { useState } from "react";

interface Msg { who: "user" | "ai"; text: string }

export default function TutorPage() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");

  return (
    <AppLayout>
      <div className="grid gap-4 grid-cols-1 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>AI Tutor</CardTitle>
              <CardDescription>Ask questions and get step-by-step help</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[50vh] overflow-auto rounded-md border p-3 space-y-3 bg-muted/20">
                {msgs.length === 0 && (
                  <div className="text-sm text-muted-foreground">Ask me anything…</div>
                )}
                {msgs.map((m, i) => (
                  <div key={i} className={m.who === "user" ? "text-right" : "text-left"}>
                    <div className={`inline-block rounded-md px-3 py-2 text-sm ${m.who === "user" ? "bg-primary text-primary-foreground" : "bg-card border"}`}>
                      {m.text}
                    </div>
                  </div>
                ))}
              </div>
              <form
                className="mt-3 flex gap-2"
                onSubmit={async (e) => {
                  e.preventDefault();
                  const q = input.trim();
                  if (!q) return;
                  setMsgs((m) => [...m, { who: "user", text: q }]);
                  setInput("");
                  const topic = /derivative|differentiate|d\/?dx/i.test(q) ? "derivative" : "general";
                  const res = await fetch("/api/ai/solve", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ topic, problem: q }),
                  });
                  const data = (await res.json()) as SolveResponse;
                  const text = data.steps.map((s) => `• ${s.step}${s.detail ? ` — ${s.detail}` : ""}`).join("\n");
                  setMsgs((m) => [...m, { who: "ai", text }]);
                }}
              >
                <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask me anything…" />
                <Button type="submit">Send</Button>
              </form>
            </CardContent>
          </Card>
        </div>
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
              <CardDescription>Enhance your learning</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full" onClick={() => explainSimpler(setMsgs, msgs)}>
                Explain simpler
              </Button>
              <Button className="w-full" variant="secondary" onClick={() => givePractice(setMsgs, msgs)}>
                Give me a practice question
              </Button>
              <Button className="w-full" variant="secondary" onClick={() => addToNotes(msgs)}>
                Add to Notes
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

function explainSimpler(setMsgs: React.Dispatch<React.SetStateAction<Msg[]>>, msgs: Msg[]) {
  const last = [...msgs].reverse().find((m) => m.who === "ai");
  if (!last) return;
  const simpler = last.text
    .split("\n")
    .map((l) => l.replace(/^•\s*/, "").toLowerCase())
    .map((l) => `• ${l}`)
    .slice(0, 5)
    .join("\n");
  setMsgs((m) => [...m, { who: "ai", text: simpler }]);
}

function givePractice(setMsgs: React.Dispatch<React.SetStateAction<Msg[]>>, msgs: Msg[]) {
  const sample = "Practice: Differentiate x^3 + 2x - 7";
  setMsgs((m) => [...m, { who: "ai", text: sample }]);
}

function addToNotes(msgs: Msg[]) {
  const text = msgs
    .filter((m) => m.who === "ai")
    .map((m) => m.text)
    .join("\n\n");
  const now = new Date().toISOString();
  const note = {
    id: Math.random().toString(36).slice(2),
    title: "AI Tutor Export",
    content: text,
    tags: ["tutor"],
    createdAt: now,
    updatedAt: now,
  };
  const notes = store.get<any[]>("notes", []);
  store.set("notes", [note, ...notes]);
}
