import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AppLayout } from "@/components/layout/AppLayout";
import { store } from "@/lib/store";
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Flashcard } from "@shared/api";
import { FlashcardsPreview } from "./_DashboardFlashcardsPreview";

export default function Dashboard() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const initialQ = params.get("q") ?? "";
  const [q, setQ] = useState(initialQ);
  useEffect(() => setQ(initialQ), [initialQ]);
  const recents = store.get<string[]>("recent:topics", []);

  return (
    <AppLayout>
      <div className="space-y-4">
        <Card>
          <CardHeader className="sticky top-[4.5rem] z-10 bg-card/60 backdrop-blur rounded-t-lg">
            <CardTitle>Quick Search</CardTitle>
            <CardDescription>
              Search any topic to explore notes, AI summaries, and practice.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center gap-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!q.trim()) return;
                const next = [q, ...recents.filter((x) => x !== q)].slice(0, 8);
                store.set("recent:topics", next);
                navigate(`/explore?q=${encodeURIComponent(q)}`);
              }}
              className="flex w-full gap-2"
            >
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Try 'Photosynthesis' or 'Derivative rules'"
              />
              <Button type="submit">Search</Button>
            </form>
          </CardContent>
        </Card>

        {/* Uniform grid of cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              id: "agenda",
              title: "Today’s Agenda",
              desc: "Your tasks for today",
              content: (
                <div className="text-sm text-muted-foreground">
                  No agenda items.
                </div>
              ),
            },
            {
              id: "focus",
              title: "Focus Timer",
              desc: "Start a Pomodoro session",
              content: (
                <div className="flex flex-col h-full justify-between">
                  <div className="mb-3">
                    <div className="text-sm text-muted-foreground">
                      25-minute sessions help focus.
                    </div>
                  </div>
                  <Link to="/practice">
                    <Button className="w-full">Start Focus Session</Button>
                  </Link>
                </div>
              ),
            },
            {
              id: "recent",
              title: "Recent Topics",
              desc: "Jump back into what you were studying",
              content: (
                <div className="grid gap-2">
                  {recents.length === 0 && (
                    <div className="text-sm text-muted-foreground">
                      No recent topics yet.
                    </div>
                  )}
                  {recents.map((t) => (
                    <Button
                      key={t}
                      variant="secondary"
                      className="justify-start"
                      onClick={() =>
                        navigate(`/explore?q=${encodeURIComponent(t)}`)
                      }
                    >
                      {t}
                    </Button>
                  ))}
                </div>
              ),
            },
            {
              id: "recommendations",
              title: "Recommendations",
              desc: "Based on your recent study activity",
              content: (
                <div className="text-sm text-muted-foreground">
                  No recommendations yet.
                </div>
              ),
            },
            {
              id: "flashcards",
              title: "Flashcards",
              desc: "Quick preview",
              content: <FlashcardsPreview />,
            },
            {
              id: "extras",
              title: "Extras",
              desc: "Tools & shortcuts",
              content: (
                <div className="text-sm text-muted-foreground">
                  No extras yet.
                </div>
              ),
            },
          ].map((c) => (
            <div key={c.id} className="">
              <div
                className="group rounded-lg border bg-card p-4 h-48 overflow-hidden flex flex-col justify-between transition-all"
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  // expand to full width
                  const el = e.currentTarget as HTMLDivElement;
                  const expanded = el.dataset.expanded === "true";
                  // toggling expansion by data attribute
                  el.dataset.expanded = (!expanded).toString();
                  if (!expanded) {
                    el.classList.remove("h-48");
                  } else {
                    el.classList.add("h-48");
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter")
                    (e.currentTarget as HTMLElement).click();
                }}
                data-expanded={"false"}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-lg font-semibold leading-tight truncate">
                        {c.title}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {c.desc}
                      </div>
                    </div>
                    <button
                      aria-label="Expand"
                      className="ml-3 text-sm rounded px-2 py-1 bg-background/40 border border-input"
                      onClick={(e) => {
                        e.stopPropagation();
                        const el = e.currentTarget.parentElement
                          ?.parentElement as HTMLDivElement | null;
                        if (!el) return;
                        const expanded = el.dataset.expanded === "true";
                        el.dataset.expanded = (!expanded).toString();
                        if (!expanded) el.classList.remove("h-48");
                        else el.classList.add("h-48");
                      }}
                    >
                      Toggle
                    </button>
                  </div>
                  <div className="mt-3 max-h-24 overflow-auto text-sm">
                    {c.content}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">&nbsp;</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
