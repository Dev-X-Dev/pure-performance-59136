import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { store } from "@/lib/store";
import { ExploreResponse } from "@shared/api";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

export default function ExplorePage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [data, setData] = useState<ExploreResponse | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const query = params.get("q");
    if (query) {
      setQ(query);
      search(query);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.get("q")]);

  async function search(query: string) {
    setLoading(true);
    try {
      const res = await fetch(`/api/explore?q=${encodeURIComponent(query)}`);
      const json = (await res.json()) as ExploreResponse;
      setData(json);
      const recents = store.get<string[]>("recent:topics", []);
      store.set(
        "recent:topics",
        [query, ...recents.filter((x) => x !== query)].slice(0, 8),
      );
    } finally {
      setLoading(false);
    }
  }

  const left = useMemo(() => data?.items ?? [], [data]);
  const right = useMemo(() => data?.condensed ?? [], [data]);

  return (
    <AppLayout>
      <div className="space-y-4">
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!q.trim()) return;
            navigate(`/explore?q=${encodeURIComponent(q)}`);
            search(q);
          }}
        >
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search topics"
          />
          <Button type="submit">Search</Button>
        </form>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Web Sources</CardTitle>
              <CardDescription>
                Raw notes and articles pulled (or crawl a URL)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <CrawlUrl
                onCrawl={(items) =>
                  setData((d) => ({
                    ...(d || { query: q, items: [], condensed: [] }),
                    items,
                  }))
                }
              />

              {loading && (
                <div className="text-sm text-muted-foreground">
                  Searching...
                </div>
              )}
              {!loading && left.length === 0 && (
                <div className="text-sm text-muted-foreground">
                  No results yet
                </div>
              )}
              {left.map((it) => (
                <div key={it.url} className="rounded-md border p-3">
                  <a
                    className="font-medium text-blue-600 hover:underline"
                    href={it.url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {it.title}
                  </a>
                  <div className="text-xs text-muted-foreground">
                    {new URL(it.url).hostname} • {it.source}
                  </div>
                  <p className="mt-1 text-sm">{it.snippet}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI-Condensed Notes</CardTitle>
              <CardDescription>Highlighted key points</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {loading && (
                <div className="text-sm text-muted-foreground">
                  Condensing...
                </div>
              )}
              {!loading && right.length === 0 && (
                <div className="text-sm text-muted-foreground">
                  No condensed notes yet
                </div>
              )}
              <ul className="list-disc pl-5 space-y-1 text-sm">
                {right.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
              {right.length > 0 && (
                <div className="pt-2">
                  <Button
                    onClick={() => {
                      const content = right.map((b) => `• ${b}`).join("\n");
                      store.set("flashcards:seed", { title: q, content });
                      navigate("/practice");
                    }}
                  >
                    Generate Flashcards from this Topic
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

function CrawlUrl({
  onCrawl,
}: {
  onCrawl: (items: ExploreResponse["items"]) => void;
}) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  async function crawl() {
    if (!url) return;
    setLoading(true);
    try {
      const res = await fetch(
        `/api/explore/crawl?url=${encodeURIComponent(url)}&depth=1`,
      );
      if (!res.ok) {
        alert("Failed to crawl url");
        return;
      }
      const json = (await res.json()) as ExploreResponse;
      onCrawl(json.items);
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="flex gap-2">
      <Input
        placeholder="Crawl a specific URL (same-origin links only)"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
      />
      <Button onClick={crawl} disabled={loading}>
        {loading ? "Crawling..." : "Crawl URL"}
      </Button>
    </div>
  );
}
