import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { store } from "@/lib/store";
import { useEffect, useState } from "react";

interface Group { id: string; name: string }

export default function GroupsPage() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [current, setCurrent] = useState<string | null>(null);
  const [board, setBoard] = useState<string>("");

  useEffect(() => {
    setGroups(store.get<Group[]>("groups", []));
  }, []);
  useEffect(() => {
    if (!current && groups[0]) setCurrent(groups[0].id);
  }, [groups, current]);
  useEffect(() => {
    if (current) setBoard(store.get<string>(`group:${current}:board`, "Share notes, links, and ideas here."));
  }, [current]);

  return (
    <AppLayout>
      <div className="grid gap-4 grid-cols-1 lg:grid-cols-4">
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Groups</CardTitle>
              <CardDescription>By class / project</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {groups.length === 0 && (
                <div className="text-sm text-muted-foreground">No groups.</div>
              )}
              {groups.map((g) => (
                <div key={g.id} className="flex items-center gap-2">
                  <Button
                    variant={current === g.id ? "default" : "secondary"}
                    className="flex-1 justify-start"
                    onClick={() => setCurrent(g.id)}
                  >
                    {g.name}
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    aria-label="Delete group"
                    onClick={() => {
                      if (!confirm(`Delete group "${g.name}"?`)) return;
                      const next = groups.filter((x) => x.id !== g.id);
                      setGroups(next);
                      store.set("groups", next);
                      if (current === g.id) setCurrent(next[0]?.id ?? null);
                    }}
                  >
                    ×
                  </Button>
                </div>
              ))}
              <Button
                variant="secondary"
                className="w-full"
                onClick={() => {
                  const name = prompt("Group name")?.trim();
                  if (!name) return;
                  const id = Math.random().toString(36).slice(2);
                  const next = [...groups, { id, name }];
                  setGroups(next);
                  store.set("groups", next);
                  setCurrent(id);
                }}
              >
                + New Group
              </Button>
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Shared Notes Board</CardTitle>
              <CardDescription>Collaborative + AI summarizer</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea rows={14} value={board} onChange={(e) => setBoard(e.target.value)} />
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={() => {
                    if (!current) return;
                    store.set(`group:${current}:board`, board);
                  }}
                >
                  Save
                </Button>
                <Button variant="secondary" onClick={summarize}>Summarize</Button>
              </div>
            </CardContent>
          </Card>
        </div>
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Group Chat</CardTitle>
              <CardDescription>Simple message board</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">No messages yet.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );

  async function summarize() {
    if (!board.trim()) return;
    const res = await fetch("/api/ai/summarize", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: board, maxBullets: 6 }),
    });
    const data = await res.json();
    if (data?.bullets) setBoard(data.bullets.map((b: string) => `• ${b}`).join("\n"));
  }
}
