import { PropsWithChildren, useMemo } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Moon,
  SunMedium,
  User,
  LayoutDashboard,
  NotebookText,
  Search,
  Bot,
  ClipboardList,
  Users,
} from "lucide-react";
import { useTheme } from "next-themes";
import { store } from "@/lib/store";

function Header() {
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const placeholder = useMemo(() => {
    switch (true) {
      case location.pathname.startsWith("/explore"):
        return "Search topics (e.g., Photosynthesis, Derivative rules)";
      default:
        return "Quick search topics";
    }
  }, [location.pathname]);

  return (
    <div className="sticky top-0 z-20 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-14 items-center gap-3 px-4">
        <SidebarTrigger />
        <Link to="/" className="flex items-center gap-2 font-bold">
          <span className="h-6 w-6 rounded bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden
            >
              <path
                d="M12 3c-2.2 0-4 1.8-4 4v1H7a3 3 0 0 0-3 3v1a3 3 0 0 0 3 3h1v1c0 2.2 1.8 4 4 4s4-1.8 4-4v-1h1a3 3 0 0 0 3-3v-1a3 3 0 0 0-3-3h-1V7c0-2.2-1.8-4-4-4z"
                fill="white"
                fillOpacity="0.95"
              />
              <path
                d="M8 11c0-1.1.9-2 2-2v6"
                stroke="white"
                strokeWidth="0.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M14 11c0-1.1-.9-2-2-2v6"
                stroke="white"
                strokeWidth="0.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <span className="text-lg tracking-tight">NoteNest</span>
        </Link>
        <div className="mx-4 flex-1 max-w-2xl">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget as HTMLFormElement;
              const data = new FormData(form);
              const q = String(data.get("q") || "").trim();
              if (!q) return;
              const recents = store.get<string[]>("recent:topics", []);
              const next = [q, ...recents.filter((x) => x !== q)].slice(0, 8);
              store.set("recent:topics", next);
              navigate(`/explore?q=${encodeURIComponent(q)}`);
              (form.elements.namedItem("q") as HTMLInputElement).value = "";
            }}
          >
            <Input name="q" placeholder={placeholder} className="w-full" />
          </form>
        </div>
        <Button
          variant="outline"
          size="icon"
          aria-label="Toggle theme"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          {theme === "dark" ? <SunMedium /> : <Moon />}
        </Button>
        <Button variant="outline" size="icon" aria-label="Profile">
          <User />
        </Button>
      </div>
    </div>
  );
}

function LeftNav() {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="px-3 py-2">
        <div className="flex items-center gap-2 rounded-md bg-gradient-to-br from-blue-600/10 to-indigo-600/10 p-2">
          <div className="h-8 w-8 rounded bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center group-data-[collapsible=icon]:h-6 group-data-[collapsible=icon]:w-6">
            {/* White brain icon over gradient */}
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden
            >
              <path
                d="M12 3c-2.2 0-4 1.8-4 4v1H7a3 3 0 0 0-3 3v1a3 3 0 0 0 3 3h1v1c0 2.2 1.8 4 4 4s4-1.8 4-4v-1h1a3 3 0 0 0 3-3v-1a3 3 0 0 0-3-3h-1V7c0-2.2-1.8-4-4-4z"
                fill="white"
                fillOpacity="0.9"
              />
              <path
                d="M8 11c0-1.1.9-2 2-2v6"
                stroke="white"
                strokeWidth="0.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M14 11c0-1.1-.9-2-2-2v6"
                stroke="white"
                strokeWidth="0.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div className="grid text-sm leading-tight group-data-[collapsible=icon]:hidden">
            <span className="font-semibold">NoteNest</span>
            <span className="text-muted-foreground">StudySphere</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigate</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {(
                [
                  { to: "/", label: "Dashboard", Icon: LayoutDashboard },
                  { to: "/notes", label: "My Notes", Icon: NotebookText },
                  { to: "/explore", label: "Explore Notes", Icon: Search },
                  { to: "/tutor", label: "AI Tutor", Icon: Bot },
                  {
                    to: "/practice",
                    label: "Quizzes & Flashcards",
                    Icon: ClipboardList,
                  },
                  { to: "/groups", label: "Groups / Collab", Icon: Users },
                ] as const
              ).map(({ to, label, Icon }) => (
                <SidebarMenuItem key={to}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(to)}
                    tooltip={label}
                  >
                    <NavLink to={to} className="flex items-center gap-2">
                      <Icon className="shrink-0" />
                      <span>{label}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarSeparator />
        <SidebarGroup>
          <SidebarGroupLabel>Shortcuts</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Start Focus Session">
                  <NavLink to="/practice" className="flex items-center gap-2">
                    <svg
                      className="size-4"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M5 3v18l15-9L5 3z" fill="currentColor" />
                    </svg>
                    <span className="group-data-[collapsible=icon]:hidden">
                      Start Focus Session
                    </span>
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="text-xs text-muted-foreground">
        <div className="px-2">v1.0</div>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}

function RightRail() {
  // Simple focus timer using session state
  return (
    <aside className="hidden xl:block w-80 border-l bg-card/30">
      <div className="sticky top-14 p-4 space-y-4">
        <div className="rounded-lg border bg-card p-4">
          <h3 className="font-semibold">Focus Timer</h3>
          <FocusTimer />
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h3 className="font-semibold">Streak</h3>
          <StudyStreak />
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h3 className="font-semibold">Wellness Tip</h3>
          <p className="text-sm text-muted-foreground">
            25–5 rule: Study 25 minutes, break 5. Hydrate and move.
          </p>
        </div>
      </div>
    </aside>
  );
}

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

function FocusTimer() {
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const ref = useRef<number | null>(null);

  useEffect(() => {
    if (!running) {
      if (ref.current) cancelAnimationFrame(ref.current);
      return;
    }
    let last = performance.now();
    const tick = (t: number) => {
      const dt = (t - last) / 1000;
      last = t;
      setSeconds((s) => Math.max(0, s - dt));
      if (seconds <= 0) setRunning(false);
      else ref.current = requestAnimationFrame(tick);
    };
    ref.current = requestAnimationFrame(tick);
    return () => {
      if (ref.current) cancelAnimationFrame(ref.current);
    };
  }, [running]);

  const mm = Math.floor(seconds / 60)
    .toString()
    .padStart(2, "0");
  const ss = Math.floor(seconds % 60)
    .toString()
    .padStart(2, "0");

  return (
    <div className="space-y-2">
      <div className="text-3xl font-mono tabular-nums">
        {mm}:{ss}
      </div>
      <div className="flex gap-2">
        <Button size="sm" onClick={() => setRunning((v) => !v)}>
          {running ? "Pause" : "Start"}
        </Button>
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            setSeconds(25 * 60);
            setRunning(false);
          }}
        >
          Reset
        </Button>
      </div>
    </div>
  );
}

function StudyStreak() {
  const key = "study:streak";
  const [count, setCount] = useState(0);
  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const data = store.get<{ last: string; count: number }>(key, {
      last: today,
      count: 0,
    });
    if (data.last !== today) {
      const last = new Date(data.last);
      const yesterday = new Date(Date.now() - 24 * 3600 * 1000);
      const isConsecutive = last.toDateString() === yesterday.toDateString();
      const next = { last: today, count: isConsecutive ? data.count + 1 : 1 };
      store.set(key, next);
      setCount(next.count);
    } else setCount(data.count || 1);
  }, []);
  return (
    <div className="flex items-center gap-3">
      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600" />
      <div>
        <div className="text-2xl font-semibold">{count} days</div>
        <div className="text-xs text-muted-foreground">Current streak</div>
      </div>
    </div>
  );
}

export function AppLayout({ children }: PropsWithChildren) {
  return (
    <SidebarProvider>
      <div className="flex h-svh">
        <LeftNav />
        <div className="flex-1 flex flex-col">
          <Header />
          <div className="flex flex-1">
            <SidebarInset className="pb-4">
              <div className="px-4 pt-4">{children}</div>
            </SidebarInset>
            <RightRail />
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}
