import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { exploreHandler } from "./routes/explore";
import { quizHandler, solveHandler, summarizeHandler } from "./routes/ai";
import { crawlHandler } from "./routes/crawl";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // StudySphere APIs
  app.get("/api/explore", exploreHandler);
  app.post("/api/ai/summarize", summarizeHandler);
  app.post("/api/ai/solve", solveHandler);
  app.post("/api/ai/quiz", quizHandler);
  app.get("/api/explore/crawl", crawlHandler);

  // Credential management (encrypted store) - requires header x-credentials-secret matching CREDENTIALS_SECRET
  const {
    storeCredentialHandler,
    getCredentialHandler,
  } = require("./routes/credentials");
  app.post("/api/credentials", storeCredentialHandler);
  app.get("/api/credentials/:id", getCredentialHandler);

  return app;
}
