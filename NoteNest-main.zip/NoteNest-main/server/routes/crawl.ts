import { ExploreResponse } from "../../shared/api";

import { ExploreResponse } from "../../shared/api";

function stripHtml(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

async function fetchText(url: string): Promise<string> {
  try {
    const res = await fetch(url, {
      headers: { "user-agent": "StudySphereBot/1.0" },
    });
    const html = await res.text();
    return stripHtml(html).slice(0, 3000);
  } catch {
    return "";
  }
}

async function allowedByRobots(root: URL, path: string): Promise<boolean> {
  try {
    const robotsUrl = new URL("/robots.txt", root.origin).toString();
    const res = await fetch(robotsUrl, {
      headers: { "user-agent": "StudySphereBot/1.0" },
    });
    if (!res.ok) return true;
    const text = await res.text();
    const lines = text.split(/\r?\n/).map((l) => l.trim());
    let userAgentSection = false;
    const disallowed: string[] = [];
    for (const line of lines) {
      if (!line) continue;
      const [k, v] = line.split(":", 2).map((s) => s.trim());
      if (/^User-agent$/i.test(k)) {
        userAgentSection = /StudySphereBot/i.test(v) || /\*/.test(v);
        continue;
      }
      if (!userAgentSection) continue;
      if (/^Disallow$/i.test(k) && v) disallowed.push(v);
    }
    for (const d of disallowed) {
      if (d === "/") return false;
      if (path.startsWith(d)) return false;
    }
    return true;
  } catch {
    return true;
  }
}

function extractLinks(html: string, base: string): string[] {
  const hrefs: string[] = [];
  const re = /<a[^>]+href=["']?([^"' >]+)["']?/gi;
  let m;
  while ((m = re.exec(html))) {
    try {
      const u = new URL(m[1], base);
      hrefs.push(u.toString());
    } catch {}
  }
  return hrefs;
}

import { fetchSitePages } from "../lib/siteParsers";
import { crawlSite } from "../lib/crawler";

export const crawlHandler: RequestHandler = async (req, res) => {
  const url = String(req.query.url || req.body?.url || "").trim();
  const maxDepth = Math.max(
    0,
    Math.min(3, Number(req.query.depth || req.body?.depth || 1)),
  );
  const maxPages = Math.max(
    1,
    Math.min(30, Number(req.query.maxPages || req.body?.maxPages || 12)),
  );
  const login = req.body?.login ?? null; // optional login info passed in request body
  if (!url) return res.status(400).json({ error: "Missing url" });

  // Respect robots.txt and do not attempt to bypass paywalls/CAPTCHAs
  try {
    // Try site-specific fetchers (which may use puppeteer/pdf parsing)
    const pages = await fetchSitePages(url, maxPages);
    let items: ExploreResponse["items"] = [];

    if (pages && pages.length > 0) {
      items = pages.map((p) => ({
        title: p.title,
        url: p.url,
        snippet: (p.text || "").slice(0, 400),
        source: new URL(url).hostname,
      }));
    } else {
      // Fallback to generic crawl with puppeteer-aware fetches
      const crawled = await crawlSite(url, maxDepth, maxPages);
      items = crawled.map((p) => ({
        title: p.title,
        url: p.url,
        snippet: (p.text || "").slice(0, 400),
        source: new URL(url).hostname,
      }));
    }

    const condensed = Array.from(
      new Set(
        items
          .flatMap((it) => it.snippet.split(/(?<=[.!?])\s+/))
          .filter((s) => s.length > 40)
          .map((s) => s.trim()),
      ),
    ).slice(0, 12);

    const payload: ExploreResponse = { query: url, items, condensed };
    res.json(payload);
  } catch (err) {
    res.status(500).json({ error: "Failed to crawl url" });
  }
};
