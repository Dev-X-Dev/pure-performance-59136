import type { RequestHandler } from "express";
import {
  GenerateQuizRequest,
  GenerateQuizResponse,
  QuizChoice,
  QuizPack,
  QuizQuestion,
  SolveRequest,
  SolveResponse,
  SummarizeRequest,
  SummarizeResponse,
  uid,
} from "../../shared/api";

// Naive summarizer: split into sentences and take top N by length, normalize
function summarize(text: string, max = 6): string[] {
  const sentences = text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  const scored = sentences
    .map((s) => ({ s, score: Math.min(200, s.length) + (s.match(/\b(e.g.|for example|thus|therefore)\b/i) ? 50 : 0) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, max)
    .map((x) => x.s);
  return Array.from(new Set(scored));
}

// Very small derivative solver for polynomial-like inputs: e.g. 3x^2 + 2x - 5
function derivativePoly(expr: string): SolveResponse {
  const cleaned = expr.replace(/\s+/g, "");
  const terms = cleaned.match(/[+-]?[^+-]+/g) || [];
  const steps: SolveResponse["steps"] = [];
  const derived: string[] = [];

  for (const t of terms) {
    const m = t.match(/^([+-]?\d+)?x(?:\^(\d+))?$|^([+-]?\d+)$/i);
    if (!m) {
      steps.push({ step: `Treat '${t}' as constant or unsupported`, detail: "d/dx of constants is 0; unsupported terms ignored." });
      continue;
    }
    if (m[3]) {
      // constant
      steps.push({ step: `d/dx(${t}) = 0`, detail: "Constant term" });
      continue;
    }
    const coeff = m[1] ? Number(m[1]) : m[0].startsWith("-") ? -1 : 1;
    const power = m[2] ? Number(m[2]) : 1;
    const newCoeff = coeff * power;
    const newPower = power - 1;
    const part = newPower === 0 ? `${newCoeff}` : newPower === 1 ? `${newCoeff}x` : `${newCoeff}x^${newPower}`;
    steps.push({ step: `d/dx(${t}) = ${part}`, detail: `Power rule: d/dx x^n = n x^{n-1}` });
    derived.push(part);
  }

  const final = derived.filter((d) => !/^0$/.test(d)).join(" + ").replace(/\+ -/g, " - ");
  steps.push({ step: `Combine results: ${final || "0"}` });
  return { steps, finalAnswer: final || "0" };
}

function makeCloze(sentence: string) {
  const words = sentence.split(/\s+/);
  const idx = Math.max(0, Math.min(words.length - 1, Math.floor(words.length / 2)));
  const answer = words[idx].replace(/[^\w-]/g, "");
  const prompt = words.map((w, i) => (i === idx ? "_____" : w)).join(" ");
  return { prompt, answer };
}

export const summarizeHandler: RequestHandler = (req, res) => {
  const { text, maxBullets = 6 } = req.body as SummarizeRequest;
  if (!text) return res.status(400).json({ error: "Missing text" });
  const bullets = summarize(text, Math.max(1, Math.min(12, maxBullets)));
  const payload: SummarizeResponse = { bullets };
  res.json(payload);
};

export const solveHandler: RequestHandler = (req, res) => {
  const { topic, problem } = req.body as SolveRequest;
  if (!topic || !problem) return res.status(400).json({ error: "Missing fields" });

  // Only a tiny subset implemented; extend with external AI later
  if (/derivative|differentiate|d\/?dx/i.test(topic + " " + problem)) {
    return res.json(derivativePoly(problem));
  }
  const fallback: SolveResponse = {
    steps: [
      { step: "Understand the problem", detail: "Identify what is being asked and the knowns/unknowns." },
      { step: "Plan a solution", detail: "Break the problem into smaller steps using relevant rules." },
      { step: "Execute and check", detail: "Apply the plan and verify the result makes sense." },
    ],
  };
  res.json(fallback);
};

export const quizHandler: RequestHandler = (req, res) => {
  const { text, count = 6 } = req.body as GenerateQuizRequest;
  if (!text) return res.status(400).json({ error: "Missing text" });

  const sentences = text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .filter((s) => s.length > 20)
    .slice(0, Math.max(3, count + 2));

  const questions: QuizQuestion[] = sentences.slice(0, count).map((s) => {
    const { prompt, answer } = makeCloze(s);
    const mcq = Math.random() > 0.5;
    if (mcq) {
      const choices: QuizChoice[] = [
        { id: uid(), text: answer, correct: true },
        { id: uid(), text: answer.split("").reverse().join(""), correct: false },
        { id: uid(), text: answer.toUpperCase(), correct: false },
        { id: uid(), text: answer.toLowerCase(), correct: false },
      ];
      return { id: uid(), type: "mcq", prompt, choices, explanation: `Key concept: ${answer}` };
    }
    return { id: uid(), type: "fill", prompt, answer, explanation: `Answer: ${answer}` };
  });

  const pack: QuizPack = { id: uid(), title: "Generated Quiz", questions };
  const payload: GenerateQuizResponse = { pack };
  res.json(payload);
};
