import { RequestHandler } from "../types";
import { setCredential, getCredential } from "../lib/credentialStore";

function checkSecret(req: any) {
  const header = req.headers["x-credentials-secret"] as string | undefined;
  const env = process.env.CREDENTIALS_SECRET || "";
  return header && env && header === env;
}

export const storeCredentialHandler: RequestHandler = (req, res) => {
  if (!checkSecret(req)) return res.status(403).json({ error: "Unauthorized" });
  const { id, data } = req.body || {};
  if (!id || !data)
    return res.status(400).json({ error: "Missing id or data" });
  try {
    setCredential(id, data);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "failed to store" });
  }
};

export const getCredentialHandler: RequestHandler = (req, res) => {
  if (!checkSecret(req)) return res.status(403).json({ error: "Unauthorized" });
  const id = String(req.params.id || req.query.id || "");
  if (!id) return res.status(400).json({ error: "Missing id" });
  const data = getCredential(id);
  if (!data) return res.status(404).json({ error: "Not found" });
  res.json({ id, data });
};
