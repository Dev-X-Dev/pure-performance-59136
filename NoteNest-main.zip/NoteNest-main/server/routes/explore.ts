import type { RequestHandler } from "express";
import { ExploreResponse } from "../../shared/api";

import { crawlSite } from "../lib/crawler";
import { fetchSitePages } from "../lib/siteParsers";

const SOURCE_BUILDERS: Record<string, (q: string) => string> = {
  // These are publicly accessible pages. Real crawling can be expanded later.
  "MIT OpenCourseWare": (q: string) =>
    `https://ocw.mit.edu/search/?q=${encodeURIComponent(q)}`,
  Docsity: (q: string) =>
    `https://www.docsity.com/en/search/?q=${encodeURIComponent(q)}`,
  Studocu: (q: string) =>
    `https://www.studocu.com/en/search/${encodeURIComponent(q)}`,
  "Course Notes": (q: string) =>
    `https://course-notes.org/search/node/${encodeURIComponent(q)}`,
  SimpleStudies: (q: string) =>
    `https://simplestudies.edublogs.org/?s=${encodeURIComponent(q)}`,
  Edubirdie: (q: string) =>
    `https://edubirdie.com/examples/?s=${encodeURIComponent(q)}`,
  Hippocampus: (q: string) =>
    `https://www.hippocampus.org/search.php?query=${encodeURIComponent(q)}`,
};

export const exploreHandler: RequestHandler = async (req, res) => {
  const q = String(req.query.q || "").slice(0, 120);
  if (!q) return res.status(400).json({ error: "Missing q" });

  const entries = await Promise.all(
    Object.entries(SOURCE_BUILDERS).map(async ([name, build]) => {
      const url = build(q);
      // Use specialized site fetchers when available, otherwise a generic crawl
      const pages = await fetchSitePages(url, 6);
      // If site-specific fetcher returned nothing, fallback to generic crawl
      const usedPages =
        pages && pages.length ? pages : await crawlSite(url, 1, 6);
      if (!usedPages || usedPages.length === 0) return null;
      // Create an item per page found (title + snippet)
      const items = usedPages.map((p) => ({
        title: p.title,
        url: p.url,
        snippet: p.text.slice(0, 400),
        source: name,
      }));
      return items;
    }),
  );

  // flatten and take top results
  const flat = (
    entries.flat().filter(Boolean) as ExploreResponse["items"]
  ).slice(0, 12);

  // Condense to bullets by naive extraction across page texts
  const condensed = Array.from(
    new Set(
      flat
        .flatMap((it) => it.snippet.split(/(?<=[.!?])\s+/))
        .filter((s) => s.length > 40)
        .slice(0, 20)
        .map((s) => s.trim()),
    ),
  ).slice(0, 8);

  const payload: ExploreResponse = { query: q, items: flat, condensed };
  res.json(payload);
};
