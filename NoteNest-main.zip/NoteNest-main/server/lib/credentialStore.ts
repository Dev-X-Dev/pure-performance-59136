import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  createHash,
} from "crypto";
import fs from "fs";
import path from "path";

const STORE_PATH =
  process.env.CREDENTIALS_STORE_PATH ||
  path.join(__dirname, "..", "credentials.json");
const SECRET = process.env.CREDENTIALS_SECRET || "";

function getKey() {
  if (!SECRET) throw new Error("CREDENTIALS_SECRET not set");
  return createHash("sha256").update(SECRET).digest(); // 32 bytes
}

function encrypt(obj: any) {
  const key = getKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const str = JSON.stringify(obj);
  const enc = Buffer.concat([cipher.update(str, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64");
}

function decrypt(b64: string) {
  const raw = Buffer.from(b64, "base64");
  const iv = raw.slice(0, 12);
  const tag = raw.slice(12, 28);
  const enc = raw.slice(28);
  const key = getKey();
  const dec = createDecipheriv("aes-256-gcm", key, iv);
  dec.setAuthTag(tag);
  const out = Buffer.concat([dec.update(enc), dec.final()]);
  return JSON.parse(out.toString("utf8"));
}

function loadStore(): Record<string, string> {
  try {
    if (!fs.existsSync(STORE_PATH)) return {};
    const raw = fs.readFileSync(STORE_PATH, "utf8");
    return JSON.parse(raw || "{}");
  } catch (err) {
    return {};
  }
}

function saveStore(store: Record<string, string>) {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), {
      mode: 0o600,
    });
  } catch (err) {
    // ignore
  }
}

export function setCredential(id: string, data: any) {
  const store = loadStore();
  store[id] = encrypt(data);
  saveStore(store);
}

export function getCredential(id: string): any | null {
  const store = loadStore();
  const v = store[id];
  if (!v) return null;
  try {
    return decrypt(v);
  } catch (err) {
    return null;
  }
}
