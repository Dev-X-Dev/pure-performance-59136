import { fetchHtml, extractLinks, stripHtml } from "./crawler";

function uniq<T>(arr: T[]) {
  return Array.from(new Set(arr));
}

function pickLongText(html: string) {
  // Try to extract main/article content heuristically
  const mainMatch = html.match(/<main[\s\S]*?<\/main>/i);
  if (mainMatch) return stripHtml(mainMatch[0]).slice(0, 8000);
  const articleMatch = html.match(/<article[\s\S]*?<\/article>/i);
  if (articleMatch) return stripHtml(articleMatch[0]).slice(0, 8000);

  // Look for large content containers by id/class keywords
  const contMatch = html.match(
    /<div[^>]+(?:id|class)=["'][^"']*(content|main|course|lecture|page|article|mw-parser-output)[^"']*["'][\s\S]*?<\/div>/i,
  );
  if (contMatch) return stripHtml(contMatch[0]).slice(0, 8000);

  // Fallback: take first big paragraph blocks
  const paraMatches = html.match(/(<p[\s\S]*?<\/p>){3,}/i);
  if (paraMatches) return stripHtml(paraMatches[0]).slice(0, 8000);

  // Hard fallback: strip entire page but truncated
  return stripHtml(html).slice(0, 8000);
}

export async function fetchMITCoursePagesFromSearch(
  searchUrl: string,
  max = 6,
) {
  // MIT OCW search pages link to course pages often under /courses/
  const html = await fetchHtml(searchUrl);
  if (!html) return [];
  const links = extractLinks(html, searchUrl);
  const courseLinks = uniq(
    links
      .map((l) => {
        try {
          const u = new URL(l, searchUrl);
          return u.toString();
        } catch {
          return null;
        }
      })
      .filter(Boolean) as string[],
  ).filter((u) => u.includes("/courses/") || u.includes("/course/"));

  const picked = courseLinks.slice(0, max);
  const pages: { title: string; url: string; text: string }[] = [];

  for (const p of picked) {
    try {
      const ph = await fetchHtml(p);
      if (!ph) continue;
      const titleMatch = ph.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : p;
      const text = pickLongText(ph);
      pages.push({ title, url: p, text });
    } catch {}
  }
  return pages;
}

export async function fetchGenericPagesFromUrl(startUrl: string, max = 6) {
  const html = await fetchHtml(startUrl);
  if (!html) return [];
  const links = extractLinks(html, startUrl);
  const uniqLinks = uniq(links).slice(0, Math.max(1, max));
  const pages: { title: string; url: string; text: string }[] = [];
  // include start page first
  try {
    const t = pickLongText(html);
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : startUrl;
    pages.push({ title, url: startUrl, text: t });
  } catch {}
  for (const l of uniqLinks) {
    try {
      const ph = await fetchHtml(l);
      if (!ph) continue;
      const titleMatch = ph.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : l;
      const text = pickLongText(ph);
      pages.push({ title, url: l, text });
      if (pages.length >= max) break;
    } catch {}
  }
  return pages.slice(0, max);
}

// Map hostnames to specialized fetchers
async function fetchDocsityPagesFromSearch(searchUrl: string, max = 6) {
  const html = await fetchHtml(searchUrl);
  if (!html) return [];
  const links = extractLinks(html, searchUrl);
  const docLinks = Array.from(
    new Set(
      links
        .map((l) => {
          try {
            return new URL(l, searchUrl).toString();
          } catch {
            return null;
          }
        })
        .filter(Boolean) as string[],
    ),
  ).filter((u) => /document|doc|download|pdf/i.test(u));

  const picked = docLinks.slice(0, max);
  const pages: { title: string; url: string; text: string }[] = [];
  for (const p of picked) {
    try {
      const ph = await fetchHtml(p);
      if (!ph) continue;
      const titleMatch = ph.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : p;
      const text = pickLongText(ph);
      pages.push({ title, url: p, text });
    } catch {}
  }
  return pages;
}

async function fetchStudocuPagesFromSearch(searchUrl: string, max = 6) {
  const html = await fetchHtml(searchUrl);
  if (!html) return [];
  const links = extractLinks(html, searchUrl);
  const docLinks = Array.from(
    new Set(
      links
        .map((l) => {
          try {
            return new URL(l, searchUrl).toString();
          } catch {
            return null;
          }
        })
        .filter(Boolean) as string[],
    ),
  ).filter((u) => /document|content|download|pdf|study/i.test(u));

  const picked = docLinks.slice(0, max);
  const pages: { title: string; url: string; text: string }[] = [];
  for (const p of picked) {
    try {
      const ph = await fetchHtml(p);
      if (!ph) continue;
      const titleMatch = ph.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : p;
      const text = pickLongText(ph);
      pages.push({ title, url: p, text });
    } catch {}
  }
  return pages;
}

async function fetchHippocampusPagesFromSearch(searchUrl: string, max = 6) {
  const html = await fetchHtml(searchUrl);
  if (!html) return [];
  const links = extractLinks(html, searchUrl);
  const contentLinks = Array.from(
    new Set(
      links
        .map((l) => {
          try {
            return new URL(l, searchUrl).toString();
          } catch {
            return null;
          }
        })
        .filter(Boolean) as string[],
    ),
  ).filter((u) => /lesson|topic|course|section|chapter|study/i.test(u));

  const picked = contentLinks.slice(0, max);
  const pages: { title: string; url: string; text: string }[] = [];
  for (const p of picked) {
    try {
      const ph = await fetchHtml(p);
      if (!ph) continue;
      const titleMatch = ph.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : p;
      const text = pickLongText(ph);
      pages.push({ title, url: p, text });
    } catch {}
  }
  return pages;
}

export const SITE_FETCHERS: Record<
  string,
  (
    url: string,
    max?: number,
  ) => Promise<{ title: string; url: string; text: string }[]>
> = {
  "ocw.mit.edu": (url: string, max = 6) =>
    fetchMITCoursePagesFromSearch(url, max),
  "mit.edu": (url: string, max = 6) => fetchMITCoursePagesFromSearch(url, max),
  "docsity.com": (url: string, max = 6) =>
    fetchDocsityPagesFromSearch(url, max),
  "www.docsity.com": (url: string, max = 6) =>
    fetchDocsityPagesFromSearch(url, max),
  "studocu.com": (url: string, max = 6) =>
    fetchStudocuPagesFromSearch(url, max),
  "www.studocu.com": (url: string, max = 6) =>
    fetchStudocuPagesFromSearch(url, max),
  "hippocampus.org": (url: string, max = 6) =>
    fetchHippocampusPagesFromSearch(url, max),
  "www.hippocampus.org": (url: string, max = 6) =>
    fetchHippocampusPagesFromSearch(url, max),
  "course-notes.org": (url: string, max = 6) =>
    fetchGenericPagesFromUrl(url, max),
};

export async function fetchSitePages(url: string, max = 6) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (SITE_FETCHERS[host]) {
      return await SITE_FETCHERS[host](url, max);
    }
    return await fetchGenericPagesFromUrl(url, max);
  } catch {
    return [];
  }
}
