export async function renderPageWithPuppeteer(
  url: string,
  login?: {
    loginUrl?: string;
    username?: string;
    password?: string;
    userSelector?: string;
    passSelector?: string;
    submitSelector?: string;
  },
) {
  let browser: any = null;
  try {
    const mod = await import("puppeteer");
    const puppeteer = mod.default || mod;
    browser = await puppeteer.launch({
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const page = await browser.newPage();
    await page.setUserAgent("StudySphereBot/1.0");
    if (login && login.loginUrl && login.username && login.password) {
      await page.goto(login.loginUrl, {
        waitUntil: "networkidle2",
        timeout: 30000,
      });
      if (login.userSelector && login.passSelector) {
        await page.type(login.userSelector, login.username);
        await page.type(login.passSelector, login.password);
        if (login.submitSelector) {
          await Promise.all([
            page.click(login.submitSelector),
            page.waitForNavigation({
              waitUntil: "networkidle2",
              timeout: 30000,
            }),
          ]);
        }
      }
    }
    await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });

    // Extract HTML
    const html = await page.content();

    await page.close();
    await browser.close();
    return { html };
  } catch (err) {
    if (browser)
      try {
        await browser.close();
      } catch {}
    return { html: null } as any;
  }
}
