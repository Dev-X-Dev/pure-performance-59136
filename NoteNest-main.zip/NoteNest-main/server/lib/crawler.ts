// Polite crawler utilities used by explore and crawl endpoints

function stripHtml(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

async function fetchHtml(
  url: string,
  usePuppeteer = false,
  login?: any,
): Promise<string | null> {
  try {
    if (usePuppeteer) {
      try {
        const mod = await import("./puppeteerCrawler");
        const r = await mod.renderPageWithPuppeteer(url, login);
        if (r && r.html) return r.html;
      } catch (err) {
        // puppeteer not available — continue to fetch normally
      }
    }

    const res = await fetch(url, {
      headers: { "user-agent": "StudySphereBot/1.0" },
      redirect: "follow",
    });
    if (!res.ok) return null;
    const text = await res.text();
    // If the page appears to be JS-heavy and puppeteer not yet used, try puppeteer
    const lower = text.slice(0, 2000).toLowerCase();
    if (
      !usePuppeteer &&
      (lower.includes("application javascript") ||
        lower.includes("enable javascript") ||
        lower.includes("var __webpack_require__") ||
        lower.includes('id="app"') ||
        lower.includes("react-root"))
    ) {
      try {
        const mod = await import("./puppeteerCrawler");
        const r = await mod.renderPageWithPuppeteer(url, login);
        if (r && r.html) return r.html;
      } catch (err) {
        // puppeteer not available — ignore
      }
    }
    return text;
  } catch (err) {
    // fallback to puppeteer if possible
    try {
      const mod = await import("./puppeteerCrawler");
      const r = await mod.renderPageWithPuppeteer(url, login);
      if (r && r.html) return r.html;
    } catch {}
    return null;
  }
}

function extractLinks(html: string, base: string): string[] {
  const hrefs: string[] = [];
  const re = /<a[^>]+href=["']?([^"' >]+)["']?/gi;
  let m;
  while ((m = re.exec(html))) {
    try {
      const u = new URL(m[1], base);
      hrefs.push(u.toString());
    } catch {}
  }
  return hrefs;
}

async function allowedByRobots(root: URL, path: string): Promise<boolean> {
  try {
    const robotsUrl = new URL("/robots.txt", root.origin).toString();
    const res = await fetch(robotsUrl, {
      headers: { "user-agent": "StudySphereBot/1.0" },
    });
    if (!res.ok) return true;
    const text = await res.text();
    const lines = text.split(/\r?\n/).map((l) => l.trim());
    let inSection = false;
    const disallowed: string[] = [];
    for (const line of lines) {
      if (!line) continue;
      const idx = line.indexOf(":");
      if (idx === -1) continue;
      const k = line.slice(0, idx).trim();
      const v = line.slice(idx + 1).trim();
      if (/^User-agent$/i.test(k)) {
        inSection = /StudySphereBot/i.test(v) || v === "*";
        continue;
      }
      if (!inSection) continue;
      if (/^Disallow$/i.test(k) && v) disallowed.push(v);
    }
    for (const d of disallowed) {
      if (d === "/") return false;
      if (path.startsWith(d)) return false;
    }
    return true;
  } catch {
    return true;
  }
}

// Crawl a site (same-origin) up to depth and page limit, returning pages with title and text
export async function crawlSite(startUrl: string, maxDepth = 1, maxPages = 8) {
  try {
    const root = new URL(startUrl);
    const seen = new Set<string>();
    const queue: Array<{ url: string; depth: number }> = [
      { url: root.toString(), depth: 0 },
    ];
    const results: { title: string; url: string; text: string }[] = [];

    while (queue.length > 0 && results.length < maxPages) {
      const { url, depth } = queue.shift()!;
      if (seen.has(url)) continue;
      seen.add(url);
      const u = new URL(url);
      if (u.origin !== root.origin) continue;
      const allowed = await allowedByRobots(root, u.pathname || "/");
      if (!allowed) continue;
      const html = await fetchHtml(url);
      if (!html) continue;
      // detect simple anti-bot pages
      const lower = html.slice(0, 2000).toLowerCase();
      if (
        lower.includes("enable javascript") ||
        lower.includes("bot verification") ||
        lower.includes("captcha") ||
        lower.includes("are you human")
      ) {
        continue;
      }
      const text = stripHtml(html).slice(0, 5000);
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : u.toString();
      results.push({ title, url, text });

      if (depth < maxDepth) {
        const links = extractLinks(html, url);
        for (const link of links) {
          try {
            const nu = new URL(link);
            if (nu.origin === root.origin && !seen.has(nu.toString())) {
              queue.push({ url: nu.toString(), depth: depth + 1 });
            }
          } catch {}
        }
      }
    }

    return results;
  } catch (err) {
    return [];
  }
}

export { stripHtml, fetchHtml, extractLinks };
